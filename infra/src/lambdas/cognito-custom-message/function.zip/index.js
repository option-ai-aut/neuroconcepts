/**
 * Cognito Custom Message Lambda Trigger
 * Handles all email templates for Immivo
 */

exports.handler = async (event) => {
  console.log('Custom message trigger:', event.triggerSource);
  
  const { userName, request, response } = event;
  const email = request.userAttributes?.email || userName;
  const code = request.codeParameter || '{####}';
  
  // Common footer
  const footer = `
Bei Fragen erreichst du uns unter support@immivo.ai

Viel Erfolg mit Immivo!

Dein Immivo Team
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Immivo - Die intelligente Plattform für Immobilienprofis
https://immivo.ai`;

  switch (event.triggerSource) {
    // Admin creates a new user (invitation)
    case 'CustomMessage_AdminCreateUser':
      response.emailSubject = '🏠 Willkommen bei Immivo - Deine Einladung';
      response.emailMessage = `Hallo!

Du wurdest zu Immivo eingeladen - der intelligenten Plattform für Immobilienprofis.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DEINE ZUGANGSDATEN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

E-Mail: ${email}
Temporäres Passwort: ${code}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SO GEHT ES WEITER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Gehe zu https://app.immivo.ai
2. Melde dich mit deiner E-Mail und dem temporären Passwort an
3. Erstelle dein persönliches Passwort

${footer}`;
      break;

    // User signs up (verification code)
    case 'CustomMessage_SignUp':
      response.emailSubject = '🏠 Willkommen bei Immivo - Bestätige deine E-Mail';
      response.emailMessage = `Hallo!

Willkommen bei Immivo! Wir freuen uns, dass du dabei bist.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DEIN VERIFIZIERUNGSCODE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${code}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Gib diesen Code ein, um deine E-Mail-Adresse zu bestätigen und dein Konto zu aktivieren.

Der Code ist 24 Stunden gültig.

${footer}`;
      break;

    // User requests to resend verification code
    case 'CustomMessage_ResendCode':
      response.emailSubject = '🏠 Immivo - Neuer Verifizierungscode';
      response.emailMessage = `Hallo!

Du hast einen neuen Verifizierungscode angefordert.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DEIN NEUER CODE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${code}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Der Code ist 24 Stunden gültig.

${footer}`;
      break;

    // User forgot password
    case 'CustomMessage_ForgotPassword':
      response.emailSubject = '🔐 Immivo - Passwort zurücksetzen';
      response.emailMessage = `Hallo!

Du hast angefordert, dein Passwort zurückzusetzen.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DEIN RESET-CODE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${code}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Gib diesen Code auf der Passwort-Reset-Seite ein, um ein neues Passwort zu erstellen.

Der Code ist 1 Stunde gültig.

Falls du diese Anfrage nicht gestellt hast, kannst du diese E-Mail ignorieren. Dein Passwort bleibt unverändert.

${footer}`;
      break;

    // Admin resets user password
    case 'CustomMessage_UpdateUserAttribute':
    case 'CustomMessage_VerifyUserAttribute':
      response.emailSubject = '🏠 Immivo - Bestätige deine Änderung';
      response.emailMessage = `Hallo!

Du hast eine Änderung an deinem Konto vorgenommen.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BESTÄTIGUNGSCODE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${code}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Gib diesen Code ein, um die Änderung zu bestätigen.

${footer}`;
      break;

    // MFA code (if enabled in future)
    case 'CustomMessage_Authentication':
      response.emailSubject = '🔐 Immivo - Dein Anmeldecode';
      response.emailMessage = `Hallo!

Hier ist dein Anmeldecode für Immivo:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${code}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Der Code ist 5 Minuten gültig.

Falls du dich nicht anmelden wolltest, ändere bitte sofort dein Passwort.

${footer}`;
      break;

    default:
      console.log('Unknown trigger source:', event.triggerSource);
  }

  return event;
};
